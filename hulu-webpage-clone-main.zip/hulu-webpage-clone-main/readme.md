# Hulu Website Clone

> This is an HTML & CSS project with a bit of JavaScript. It is a clone of the Hulu homepage and part of a [YouTube tutorial](https://www.youtube.com/watch?v=9OVLaEjY-Rc)

![Hulu Clone](/img/screen.png 'Hulu Clone')
